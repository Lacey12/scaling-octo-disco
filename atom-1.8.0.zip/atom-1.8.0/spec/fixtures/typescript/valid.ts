var inc = v => v + 1
export = inc
