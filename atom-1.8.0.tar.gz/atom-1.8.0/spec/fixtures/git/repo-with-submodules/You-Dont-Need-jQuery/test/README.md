# Test cases for all the tips

## Usage

run all tests once
```
npm run test
```

run tests on TDD(Test Driven Development) mode
```
npm run tdd
```
