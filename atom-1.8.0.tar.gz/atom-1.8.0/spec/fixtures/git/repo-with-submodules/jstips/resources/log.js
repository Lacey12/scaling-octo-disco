(() => {
	console.log('Hello world');
})();