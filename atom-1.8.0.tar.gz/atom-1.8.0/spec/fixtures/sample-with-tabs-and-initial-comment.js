/**
 * Look, this is a comment. Don't go making assumtions that I want soft tabs
 * because this block comment has leading spaces, Geez.
 */

if (beNice) {
	console.log('Thank you for being nice.');
}
