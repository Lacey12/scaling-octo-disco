process.stdout.write(process.argv[2]);
